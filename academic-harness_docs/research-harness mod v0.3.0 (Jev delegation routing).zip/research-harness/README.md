# research-harness

An academic/scientific research harness for Claude Code, built as a mod.

It gives Claude **tools** that handle the data plumbing of a literature review and gives you a **/research** command that walks through the review stages. All project data is stored as auditable JSONL files in a `research/` directory in your project.

## What it provides

**Command (for you):**

- `/research start` — set up `research/` and write a protocol with you (creates only missing files; never truncates)
- `/research search` — run the protocol's search strategy
- `/research screen` — title/abstract screening in confirmed batches
- `/research fulltext` — full-text screening of the title/abstract includes
- `/research extract` — evidence extraction with quotes and locations
- `/research report` — write the final report with DOI identity lookups
- `/research status` — review funnel counts
- `/research routing` — Jev delegation-routing status (mode, packs, decision counts)
- `/research help` — list stages

**Tools (for Claude):**

- `search_papers` — search OpenAlex or Crossref, dedupe by DOI, log every query (including failures)
- `screen_paper` — record a screening decision with a reason, per stage (title/abstract, full text)
- `save_evidence` — save a claim, verbatim quote, and location for a full-text-included record
- `verify_doi` — Crossref identity lookup for a DOI; logs to `doi_checks.jsonl`
- `harness_status` — two-stage review funnel counts

**Status line:** a line under the prompt shows the review funnel whenever a harness tool runs.

## Data layout

```
research/
├── protocol.md        research question, criteria, search strategy
├── search_log.jsonl   every query: date, source, outcome, counts
├── records.jsonl      deduplicated publication records
├── screening.jsonl    one row per decision + reason, per stage
├── evidence.jsonl     extracted evidence with locations
├── doi_checks.jsonl   every DOI lookup with outcome
└── report.md          the final report
```

## Use it

```bash
cd your-project
claude --plugin-dir /path/to/research-harness
```

Then, inside the session: `/research start`.

## Jev delegation routing (optional, v0.3.0)

When Claude delegates a task to a subagent, the mod can ask Jev how demanding the task is and what kind of work it is, then pick a cheaper model tier (haiku, sonnet, opus) and, if configured, a tool/skill pack. It is a hook on `agent.spawn`; the subagent starts a fresh conversation, so the choice does not disturb any prompt cache. Jev never judges papers.

- `JEV_ROUTING_MODE`: `shadow` (default; logs the choice it would make and changes nothing), `enforce`, or `off`
- `TYPESAFE_API_KEY`: required for any routing; with no key the hook does nothing
- `JEV_ROUTING_EXCERPT=off`: send only the short task description, not the start of the brief
- `research/packs.json`: optional tool/skill packs and main-session tool placement; see `examples/packs.example.json`
- Logs: `research/jev_delegations.jsonl`, `research/jev_delegation_outcomes.jsonl`; summarize with `tools/delegation_report.py`

Optional environment variables:

- `OPENALEX_API_KEY` — OpenAlex is free for casual use with no key; a free key raises your daily budget 10x
- `CROSSREF_MAILTO` — Crossref's open API asks for a contact address to enter its polite pool

## Test it

```bash
claude plugin validate /path/to/research-harness
claude plugin test          # from the research-harness directory
```

## Notes and limits

- Needs Claude Code v2.1.287 or later (mods). Jev routing was built against the `agent.spawn`, `turn.step`, `turn.complete` and `tool.describe` events as declared in Claude Code 2.1.277 types; check `.claude-plugin/types/` for your build.
- Literature data comes from the OpenAlex and Crossref APIs; unauthenticated requests were tested and worked. Check the providers' current policies: OpenAlex allows casual keyless use (100 requests/second cap; 429s when the daily budget is exceeded) and Crossref's REST API is open and free, asking for a `mailto` contact for its polite pool.
- The search tool retrieves the first relevance-ranked batch per query (no pagination), so coverage is the top-relevance slice, not exhaustive.
- `verify_doi` is a publication-identity lookup only; it does not confirm that a paper supports a claim, and a failed lookup does not prove a DOI is invalid.
- Records carry database-supplied publication-type metadata, which needs interpretation (for example, preprint servers commonly register works as preprint or posted-content types); the harness does not verify peer-review or retraction status.
- Single-writer: use one session per `research/` directory; within a session, mutations are serialized by a lock, but the JSONL files are read-modify-write.
- The mod does not make your review a systematic review by itself — it keeps the audit trail; you make the decisions.
