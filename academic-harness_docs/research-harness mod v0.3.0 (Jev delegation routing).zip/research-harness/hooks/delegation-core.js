// delegation-core.js - the pure, $-free half of Jev delegation routing.
//
// Jev's job in this harness is one decision: when Claude delegates a task to a
// subagent, how demanding is the task, and what kind of work is it? Code then
// maps those answers to a model tier (haiku / sonnet / opus) and, optionally,
// to a "pack": a subagent type with a fixed tool and skill allowlist.
//
// Jev never judges a paper, a claim or a criterion, and it never executes
// anything. Floors, ceilings, thresholds and holds are all deterministic code.
//
// Anything that touches the mods API ($) lives in register.js, because the
// validator only traces `$` through functions in the same file.

// Uncalibrated starting points. The routing paper behind this design also acts
// only when probabilities clear 0.8 and otherwise holds the turn on its home
// model; tune on your own pilot data.
export const MIN_PROBABILITY = 0.8
export const STAKES_RAISE = 0.5
export const NEEDS_CONTEXT_MAX = 0.2

// Tiers, cheapest first. `alias` is what the agent.spawn hook sets as `model`.
export const TIERS = [
  { name: 'fast', alias: 'haiku', effort: 'low' },
  { name: 'balanced', alias: 'sonnet', effort: 'medium' },
  { name: 'strong', alias: 'opus', effort: 'high' }
]

// What kind of work the delegated task is. These are academic-harness actions,
// not paper judgments.
export const ACTIONS = {
  lookup_transform: 'Mechanical work with clear rules: find, count, dedupe, rename, convert or reformat data or files.',
  discover_sources: 'Find candidate papers, datasets or web sources for a topic.',
  verify_citations: 'Check citations, quotes or references against their sources.',
  read_extract: 'Read supplied documents and pull out stated facts, fields or passages.',
  analyze_data: 'Compute statistics, run code over supplied data, or make figures.',
  interpret_synthesize: 'Interpret findings, weigh evidence, reconcile conflicts, or design a method or protocol.',
  draft_write: 'Draft or revise prose, a report section or a reference list.',
  other: 'None of the above clearly fits.'
}

// The lowest tier index each action may run on, even when Jev rates it easy.
export const ACTION_FLOORS = {
  lookup_transform: 0,
  discover_sources: 0,
  verify_citations: 1,
  read_extract: 1,
  analyze_data: 1,
  draft_write: 1,
  interpret_synthesize: 2,
  other: 1
}

const COMPLEXITY_RUBRIC = [
  'Trivial: a lookup, count, rename or reformat with clear rules',
  'Routine: a well-specified task using a standard method',
  'Complex: multi-step reasoning, judgement, or reconciling several sources',
  'Expert: open-ended design or interpretation where errors are subtle'
]

function clip(text, n) {
  const s = String(text === undefined || text === null ? '' : text)
  return s.length > n ? s.slice(0, n) + ' [truncated]' : s
}

// The tier index of a model name, or null if it is not one we recognize.
export function tierOfModel(name) {
  const s = String(name || '').toLowerCase()
  if (s.indexOf('haiku') !== -1) return 0
  if (s.indexOf('sonnet') !== -1) return 1
  if (s.indexOf('opus') !== -1) return 2
  return null
}

// Build the POST /v1/systemone body. The state is a plain string. Only the
// short description and a clipped excerpt of the brief are sent.
export function buildDelegationRequest(input, sendExcerpt) {
  const parts = ['A parent AI agent is delegating a task to a subagent that starts with no conversation history.']
  parts.push('Task description: ' + clip(input.description, 200))
  if (sendExcerpt) parts.push('Start of the task brief: ' + clip(input.prompt, 600))
  parts.push('Subagent type: ' + clip(input.subagentType, 80))
  return {
    model: 'jev-latest',
    state: parts.join('\n'),
    questions: {
      action: {
        type: 'choice',
        instructions: 'What kind of work is the delegated task mainly?',
        criteria: ACTIONS
      },
      complexity: {
        type: 'score',
        instructions: 'How demanding is the delegated task for the model that performs it?',
        criteria: COMPLEXITY_RUBRIC
      },
      high_stakes: {
        type: 'noul',
        instructions: 'A mistake in this task output would be costly or hard to notice, for example because it feeds a citation, an inclusion decision, a statistic or a conclusion.'
      },
      needs_conversation: {
        type: 'noul',
        instructions: 'The task cannot be done well without context from the earlier conversation that the brief does not contain.'
      }
    }
  }
}

function num(v) {
  return typeof v === 'number' && isFinite(v) ? v : null
}

// Cumulative probability that the task's complexity level is at or below `k`
// (levels 0..3). Missing levels count as 0, so a malformed map cannot pass.
function cumulative(probs, k) {
  let total = 0
  for (let i = 0; i <= k; i++) {
    const p = num(probs[String(i)])
    if (p !== null) total += p
  }
  return total
}

// Decide what to do with a Jev answer. Returns a decision with status
// 'route' (change the spawn) or 'hold' (leave it exactly as Claude asked).
// ctx: { parentModel, packs (optional, from mergePacks), thresholds (optional) }
export function decideDelegation(response, ctx) {
  const minP = ctx.thresholds && ctx.thresholds.minProbability !== undefined ? ctx.thresholds.minProbability : MIN_PROBABILITY
  const out = {
    status: 'hold', reason: '', tier: null, model: null, effort: null, pack: null,
    action: null, actionP: null, complexity: null, stakes: null, needsConversation: null
  }
  const a = response && response.answers
  if (!a || !a.action || !a.complexity || !a.high_stakes || !a.needs_conversation ||
      typeof a.action.choice !== 'string' || !a.action.probabilities || !a.complexity.probabilities ||
      num(a.high_stakes.noul) === null || num(a.needs_conversation.noul) === null) {
    out.reason = 'malformed_response'
    return out
  }
  out.action = a.action.choice
  out.actionP = num(a.action.probabilities[a.action.choice])
  out.complexity = {}
  for (const k of ['0', '1', '2', '3']) out.complexity[k] = num(a.complexity.probabilities[k])
  out.stakes = num(a.high_stakes.noul)
  out.needsConversation = num(a.needs_conversation.noul)

  const parent = tierOfModel(ctx.parentModel)
  if (parent === null) {
    out.reason = 'unknown_parent_model'
    return out
  }
  if (out.needsConversation > NEEDS_CONTEXT_MAX) {
    out.reason = 'needs_conversation_context'
    return out
  }

  // The cheapest tier whose cumulative probability clears the threshold.
  let tier = 2
  if (cumulative(a.complexity.probabilities, 0) >= minP) tier = 0
  else if (cumulative(a.complexity.probabilities, 1) >= minP) tier = 1
  out.complexityTier = tier

  // Floors. A confident action sets its own floor; an unsure one defaults to balanced.
  const knownAction = Object.prototype.hasOwnProperty.call(ACTION_FLOORS, out.action)
  const actionSure = knownAction && out.actionP !== null && out.actionP >= minP
  const floor = actionSure ? ACTION_FLOORS[out.action] : 1
  if (tier < floor) tier = floor
  if (out.stakes >= STAKES_RAISE && tier < 1) tier = 1
  if (out.stakes >= 0.8 && tier < 2) tier = tier + 1

  // Ceiling: never above the parent's own model.
  let capped = false
  if (tier > parent) {
    tier = parent
    capped = true
  }
  out.tier = tier
  out.model = TIERS[tier].alias
  out.effort = TIERS[tier].effort

  // A pack is chosen only when the action is confidently identified.
  if (actionSure && ctx.packs) {
    for (const p of ctx.packs) {
      if (p.actions.indexOf(out.action) !== -1) {
        out.pack = p.name
        break
      }
    }
  }

  if (tier === parent && !out.pack) {
    out.reason = capped ? 'capped_by_parent_no_change' : 'same_as_parent'
    return out
  }
  out.status = 'route'
  out.reason = capped ? 'routed_capped_by_parent' : 'routed'
  return out
}

// ---- packs: named subagent types with tool and skill allowlists ----

const NAME_PATTERN = /^[A-Za-z0-9_-]{1,64}$/
const TOOL_PATTERN = /^[A-Za-z0-9_\-:.]{1,200}$/

export const DEFAULT_PACK_PROMPT = [
  'You are a focused research-assistant subagent. Do exactly the task in the brief you are given.',
  'Use only the tools you have. Report concisely what you did and what you found, with the source of every fact.',
  'Never invent citations, quotes, numbers or DOIs. If you cannot do part of the task, say which part and why.'
].join('\n')

// Validate research/packs.json. Invalid entries are skipped and reported.
// Shape: { "packs": [ { name, description, actions[], tools[], skills[], prompt? } ],
//          "mainSession": { "pin": [...], "defer": [...] } }
export function mergePacks(raw) {
  const warnings = []
  const packs = []
  const main = { pin: [], defer: [] }
  if (raw === undefined || raw === null) return { packs: packs, mainSession: main, warnings: warnings }
  if (typeof raw !== 'object' || Array.isArray(raw)) {
    warnings.push('packs.json must be a JSON object; ignored')
    return { packs: packs, mainSession: main, warnings: warnings }
  }
  const list = Array.isArray(raw.packs) ? raw.packs : []
  const seen = {}
  for (const p of list) {
    if (!p || typeof p.name !== 'string' || !NAME_PATTERN.test(p.name)) {
      warnings.push('skipped a pack with an invalid name')
      continue
    }
    if (seen[p.name]) {
      warnings.push('skipped duplicate pack ' + p.name)
      continue
    }
    if (typeof p.description !== 'string' || p.description.trim() === '') {
      warnings.push('skipped ' + p.name + ': missing description')
      continue
    }
    const actions = Array.isArray(p.actions) ? p.actions.filter(function (a) { return Object.prototype.hasOwnProperty.call(ACTIONS, a) }) : []
    if (actions.length === 0) {
      warnings.push('skipped ' + p.name + ': no valid actions (use: ' + Object.keys(ACTIONS).join(', ') + ')')
      continue
    }
    const tools = Array.isArray(p.tools) ? p.tools.filter(function (t) { return typeof t === 'string' && TOOL_PATTERN.test(t) }) : []
    if (tools.length === 0) {
      warnings.push('skipped ' + p.name + ': a pack needs a non-empty tools allowlist (that is what makes it a pack)')
      continue
    }
    seen[p.name] = true
    packs.push({
      name: p.name,
      description: p.description.trim(),
      actions: actions,
      tools: tools,
      skills: Array.isArray(p.skills) ? p.skills.filter(function (s) { return typeof s === 'string' && NAME_PATTERN.test(s) }) : [],
      prompt: typeof p.prompt === 'string' && p.prompt.trim() !== '' ? p.prompt : DEFAULT_PACK_PROMPT
    })
  }
  const ms = raw.mainSession
  if (ms && typeof ms === 'object') {
    if (Array.isArray(ms.pin)) main.pin = ms.pin.filter(function (t) { return typeof t === 'string' && TOOL_PATTERN.test(t) })
    if (Array.isArray(ms.defer)) main.defer = ms.defer.filter(function (t) { return typeof t === 'string' && TOOL_PATTERN.test(t) })
    const overlap = main.pin.filter(function (t) { return main.defer.indexOf(t) !== -1 })
    if (overlap.length > 0) {
      warnings.push('tools in both pin and defer were left pinned: ' + overlap.join(', '))
      main.defer = main.defer.filter(function (t) { return overlap.indexOf(t) === -1 })
    }
  }
  return { packs: packs, mainSession: main, warnings: warnings }
}

// The argument for $.agent.register. Model and effort are deliberately left
// out: the spawn hook sets them per task.
export function buildAgentSpec(pack) {
  const spec = {
    name: pack.name,
    description: pack.description,
    prompt: pack.prompt,
    tools: pack.tools
  }
  if (pack.skills.length > 0) spec.skills = pack.skills
  return spec
}
