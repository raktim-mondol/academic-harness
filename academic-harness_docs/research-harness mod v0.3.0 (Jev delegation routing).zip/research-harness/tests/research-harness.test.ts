import { expect, test } from 'claude-code/testing'

test('/research help lists the stages', async ($, on) => {
  const answer = await $.command.run({ command: 'research', args: 'help' })
  expect(answer.text).toContain('screen')
  expect(answer.text).toContain('fulltext')
  expect(answer.text).toContain('extract')
})

test('/research rejects an unknown stage', async ($, on) => {
  const answer = await $.command.run({ command: 'research', args: 'bogus' })
  expect(answer.text).toContain('unknown stage')
})

test('/research start hands the setup instructions to Claude', async ($, on) => {
  const answer = await $.command.run({ command: 'research', args: 'start' })
  expect(answer.text).toContain('research-harness (start)')
  expect(answer.text).toContain('protocol.md')
})

test('/research fulltext hands the full-text screening instructions to Claude', async ($, on) => {
  const answer = await $.command.run({ command: 'research', args: 'fulltext' })
  expect(answer.text).toContain('research-harness (fulltext)')
  expect(answer.text).toContain('full_text')
})


test('/research routing reports the delegation routing status', async ($, on) => {
  const answer = await $.command.run({ command: 'research', args: 'routing' })
  expect(answer.text).toContain('Jev delegation routing')
  expect(answer.text).toContain('mode:')
})
