#!/usr/bin/env python3
"""Summarize the Jev delegation-routing pilot from research/jev_delegations.jsonl
and research/jev_delegation_outcomes.jsonl. Usage: python3 delegation_report.py [research_dir]"""
import json, sys, os, collections

d = sys.argv[1] if len(sys.argv) > 1 else "research"

def rows(name):
    p = os.path.join(d, name)
    if not os.path.exists(p):
        return []
    out = []
    for i, line in enumerate(open(p, encoding="utf-8"), 1):
        if not line.strip():
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            sys.exit(f"{name} line {i} is not valid JSON")
    return out

dec = rows("jev_delegations.jsonl")
outc = rows("jev_delegation_outcomes.jsonl")
print(f"delegations seen: {len(dec)}")
print("  status/reason:", dict(collections.Counter(f"{r.get('status')}:{r.get('reason')}" for r in dec)))

asked = [r for r in dec if r.get("action")]
print(f"  Jev answered for: {len(asked)}")
print("  actions:", dict(collections.Counter(r["action"] for r in asked)))
would = collections.Counter(r.get("wouldModel") for r in asked if r.get("status") == "route")
print("  would route to:", dict(would))
print("  applied (enforce mode):", sum(1 for r in dec if r.get("applied")))
lat = sorted(r["latencyMs"] for r in dec if isinstance(r.get("latencyMs"), (int, float)))
if lat:
    print(f"  Jev latency ms: median {lat[len(lat)//2]}, max {lat[-1]}")

by_id = {r["id"]: r for r in dec}
tok = collections.defaultdict(lambda: [0, 0, 0, 0.0])  # n, in, out, ms by (applied, model)
for o in outc:
    u = o.get("usage") or {}
    key = (("enforced" if o.get("applied") else "unrouted"), u.get("model", "?"))
    t = tok[key]
    t[0] += 1
    t[1] += u.get("input_tokens", 0) or 0
    t[2] += u.get("output_tokens", 0) or 0
    t[3] += o.get("durationMs", 0) or 0
print("outcomes by (routing, model): n, input tokens, output tokens, mean seconds")
for k, (n, i, o_, ms) in sorted(tok.items()):
    print(f"  {k}: n={n} in={i} out={o_} mean_s={ms/n/1000:.1f}")
print("note: compare quality by hand; tokens alone do not show whether the output was good enough.")
